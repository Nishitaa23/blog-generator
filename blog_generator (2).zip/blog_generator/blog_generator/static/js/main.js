// This file can contain any additional JavaScript functionality
// Currently it's just a placeholder as most functionality is handled inline
// or with Flask

document.addEventListener('DOMContentLoaded', function() {
    // Add loading state to form submission
    const form = document.querySelector('form');
    const generateBtn = document.querySelector('.generate-btn');
    
    if (form) {
        form.addEventListener('submit', function() {
            generateBtn.innerHTML = 'Generating... <span class="spinner"></span>';
            generateBtn.disabled = true;
        });
    }
});