import os
import markdown
from flask import Flask, render_template, request
from markupsafe import Markup
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

def format_blog_content(content):
    """
    Format the blog content from plain text to HTML with proper structure
    """
    # Convert markdown to HTML
    html_content = markdown.markdown(
        content,
        extensions=['extra', 'nl2br']
    )
    
    # Clean up any double line breaks or other formatting issues
    html_content = html_content.replace('<p><br></p>', '<br>')
    
    return Markup(html_content)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        # Get the user input from the form
        user_input = request.form['prompt']
        
        try:
            # Import here to avoid initialization issues
            import groq
            
            # Create a new client instance inside the function
            client = groq.Client(api_key=os.environ.get("GROQ_API_KEY"))
            
            # Enhance the prompt to request well-structured content
            enhanced_prompt = f"""
            Generate a well-structured blog post about the following topic:
            
            {user_input}
            
            Please include:
            - A catchy title (formatted as H1)
            - An introduction
            - Multiple sections with proper headings (H2)
            - Bullet points or numbered lists where appropriate
            - A conclusion
            
            Format the content using markdown for proper structure.
            """
            
            # Call the Groq API with the enhanced prompt
            chat_completion = client.chat.completions.create(
                messages=[
                    {
                        "role": "user",
                        "content": enhanced_prompt,
                    }
                ],
                model="llama-3.3-70b-versatile",
            )
            
            # Extract the blog content generated
            raw_blog_content = chat_completion.choices[0].message.content
            
        except Exception as e:
            # Handle any errors with the Groq API
            raw_blog_content = f"# Error Generating Blog\n\nThere was an error communicating with the Groq API: {str(e)}\n\nPlease check your API key and try again."
        
        # Format the blog content to have proper HTML structure
        formatted_blog_content = format_blog_content(raw_blog_content)
        
        # Render the result page with the formatted blog content
        return render_template('result.html', blog_content=formatted_blog_content)
    
    # Render the index page with the input form
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)